#include "Tank.h"

HRESULT Tank::Init()
{
	return S_OK;
}

void Tank::Release()
{
}

void Tank::Update()
{
}

void Tank::Render(HDC hdc)
{
}

Tank::Tank()
{
}

Tank::~Tank()
{
}
