#include "EnemyTank.h"

HRESULT EnemyTank::Init()
{
	return S_OK;
}

void EnemyTank::Release()
{
}

void EnemyTank::Update()
{
}

void EnemyTank::Render(HDC hdc)
{
}

EnemyTank::EnemyTank()
{
}

EnemyTank::~EnemyTank()
{
}
