#include "Image.h"
#include "MainGame.h"
#include "TitleScene.h"
#include "LoadingScene.h"
#include "BattleScene.h"
#include "TilemapToolScene.h"
#include "IsometricScene.h"

HRESULT MainGame::Init()
{
	hdc = GetDC(g_hWnd);

	// backBuffer
	backBuffer = new Image();
	backBuffer->Init(WINSIZE_X, WINSIZE_Y);

	KeyManager::GetSingleton()->Init();
	ImageManager::GetSingleton()->Init();
	TimeManager::GetSingleton()->Init();
	SoundManager::GetSingleton()->Init();
	SceneManager::GetSingleton()->Init();
	DataCollector::GetSingleton()->Init();
	
	battleScene = new BattleScene();
	SceneManager::GetSingleton()->AddScene("��Ʋ��", battleScene);
	//battleScene->Init();

	titleScene = new TitleScene();
	SceneManager::GetSingleton()->AddScene("Ÿ��Ʋ", titleScene);
	//titleScene->Init();

	loadingScene = new LoadingScene();
	SceneManager::GetSingleton()->AddLoadingScene("�ε�1", loadingScene);
	//loadingScene->Init();

	tileMapToolScene = new TilemapToolScene();
	SceneManager::GetSingleton()->AddScene("�ʿ�����", tileMapToolScene);
	//tileMapToolScene->Init();

	isometricScene = new IsometricScene();
	SceneManager::GetSingleton()->AddScene("���̼Ҹ�Ʈ��", isometricScene);
	//isometricScene->Init();

	//SceneManager::GetSingleton()->ChangeScene("�ʿ�����");
	SceneManager::GetSingleton()->ChangeScene("���̼Ҹ�Ʈ��");

	isInit = true;

	return S_OK;
}

void MainGame::Release()
{
	isometricScene->Release();
	SAFE_DELETE(isometricScene);

	loadingScene->Release();
	SAFE_DELETE(loadingScene);

	titleScene->Release();
	SAFE_DELETE(titleScene);

	battleScene->Release();
	SAFE_DELETE(battleScene);

	DataCollector::GetSingleton()->ReleaseSingleton();
	
	SceneManager::GetSingleton()->Release();
	SceneManager::GetSingleton()->ReleaseSingleton();

	SoundManager::GetSingleton()->Release();
	SoundManager::GetSingleton()->ReleaseSingleton();

	TimeManager::GetSingleton()->Release();
	TimeManager::GetSingleton()->ReleaseSingleton();
	
	ImageManager::GetSingleton()->Release();
	ImageManager::GetSingleton()->ReleaseSingleton();

	KeyManager::GetSingleton()->Release();
	KeyManager::GetSingleton()->ReleaseSingleton();

	backBuffer->Release();
	delete backBuffer;

	ReleaseDC(g_hWnd, hdc);
}

void MainGame::Update()
{
	SceneManager::GetSingleton()->Update();

	//if (tileMapToolScene)
	//	tileMapToolScene->Update();

	
	InvalidateRect(g_hWnd, NULL, false);
}

void MainGame::Render()
{	
	SceneManager::GetSingleton()->Render(backBuffer->GetMemDC());

	//TimeManager::GetSingleton()->Render(backBuffer->GetMemDC());

	//if(tileMapToolScene)
	//	tileMapToolScene->Render(backBuffer->GetMemDC());
	
	backBuffer->Render(hdc, 0, 0);
}

LRESULT MainGame::MainProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage)
	{
	case WM_MOUSEMOVE:
		g_ptMouse.x = LOWORD(lParam);
		g_ptMouse.y = HIWORD(lParam);
		break;

	case WM_TIMER:
		//if (isInit)
		//	this->Update();
		break;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		//if (isInit)
		//	this->Render(hdc);

		EndPaint(hWnd, &ps);
		break;
	case WM_KEYDOWN:
		switch (wParam)
		{
		case VK_ESCAPE:
			PostQuitMessage(0);
			break;
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	}

	return DefWindowProc(hWnd, iMessage, wParam, lParam);
}


MainGame::MainGame()
	: isInit(false)
{
}


MainGame::~MainGame()
{
}
