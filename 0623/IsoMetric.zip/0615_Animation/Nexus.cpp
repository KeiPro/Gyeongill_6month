#include "Nexus.h"
#include "Image.h"

HRESULT Nexus::Init()
{
	image = ImageManager::GetSingleton()->AddImage("�ؼ���", "Image/Nexus.bmp", 0, 0, 32, 16, 2, 1, true);
	nexusPos = DataCollector::GetSingleton()->GetNexusRegenPoint();
	isHit = false;
	currKeyframeX = 0;
	rc = GetRectToCenter(nexusPos.x, nexusPos.y, 48, 48);

	return S_OK;
}

void Nexus::Release()
{

}

void Nexus::Update()
{
	if (isHit == true)
	{
		currKeyframeX = 1;
	}
}

void Nexus::Render(HDC hdc)
{
	if (image)
		image->FrameRender(hdc, nexusPos.x, nexusPos.y, currKeyframeX, 0, 3.0f);
}

void Nexus::SetCurrKeyFrame(int keyX)
{
	currKeyframeX = keyX;
	SceneManager::GetSingleton()->ChangeScene("Ÿ��Ʋ");
}

Nexus::Nexus()
{

}

Nexus::~Nexus()
{
}
