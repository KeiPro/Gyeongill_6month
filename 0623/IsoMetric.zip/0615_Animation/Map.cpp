#include "Map.h"
#include "Image.h"

HRESULT Map::Init()
{
	image = ImageManager::GetSingleton()->AddImage("����Ÿ��", "Image/TileSheet.bmp", 0, 0, 48, 8, SAMPLE_TILE_X, SAMPLE_TILE_Y, true, RGB(0,0,1));
	

	playerRegenPoint = { TILE_SIZE * 10 , TILE_SIZE * 26};
	
	nexusRegenPoint = { TILE_SIZE * 16, TILE_SIZE * 30};

	DataCollector::GetSingleton()->SetPlayerRegenPoint(playerRegenPoint);

	DataCollector::GetSingleton()->SetNexusRegenPoint(nexusRegenPoint);

	LoadMap();
	
	return S_OK;
}

void Map::Release()
{
}

void Map::Update()
{

}

void Map::Render(HDC hdc)
{

	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		if(tileInfo[i].terrain != TR_NONE)
			image->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY, 3.0f);
	}
	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		//Rectangle(hdc, tileInfo[i].rcTile.left, tileInfo[i].rcTile.top, tileInfo[i].rcTile.right, tileInfo[i].rcTile.bottom);
	}
}

void Map::LoadMap()
{
	DWORD readByte;
	HANDLE hFile;

	hFile = CreateFile("Save/baseFrame.map", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL); //������ ���� ������ �ȿ���
	ReadFile(hFile, tileInfo, sizeof(TILE_INFO) * TILE_X * TILE_Y, &readByte, NULL);
	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		if (tileInfo[i].frameX == 0)
		{
			tileInfo[i].terrain = TR_WALL;
		}
		else if (tileInfo[i].frameX == 1)
		{
			tileInfo[i].terrain = TR_CEMENT;
		}
		else if (tileInfo[i].frameX == 2)
		{
			tileInfo[i].terrain = TR_IRON;
		}
		else if (tileInfo[i].frameX == 3)
		{
			tileInfo[i].terrain = TR_GRASS;
		}
		else if (tileInfo[i].frameX == 4)
		{
			tileInfo[i].terrain = TR_WATER;
		}
		else if (tileInfo[i].frameX == 5)
		{
			tileInfo[i].terrain = TR_NONE;
		}
	}

	DataCollector::GetSingleton()->SetTileInfo(tileInfo);


	CloseHandle(hFile);
}

Map::Map()
{
}

Map::~Map()
{
}
