#include "BattleScene.h"
#include "Battle.h"
#include "UIBattle.h"


HRESULT BattleScene::Init()
{
	battle = new Battle();
	battle->Init();

	uiBattle = new UIBattle();
	uiBattle->Init();

	Sleep(2000);

	return S_OK;
}

void BattleScene::Release()
{
	if (battle)
	{
		battle->Release();
		SAFE_DELETE(battle);
	}

	if (uiBattle)
	{
		uiBattle->Release();
		SAFE_DELETE(uiBattle);
	}

}

void BattleScene::Update()
{
	if (battle)
		battle->Update();

	if (uiBattle)
		uiBattle->Update();
}

void BattleScene::Render(HDC hdc)
{
	if (battle)
	{
		battle->Render(hdc);
	}
}

BattleScene::BattleScene()
{
}

BattleScene::~BattleScene()
{
}
