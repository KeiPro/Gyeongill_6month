#include "UIBattle.h"

HRESULT UIBattle::Init()
{


	return S_OK;
}

void UIBattle::Release()
{
}

void UIBattle::Update()
{
}

void UIBattle::Render(HDC hdc)
{
}

UIBattle::UIBattle()
{
}

UIBattle::~UIBattle()
{
}
