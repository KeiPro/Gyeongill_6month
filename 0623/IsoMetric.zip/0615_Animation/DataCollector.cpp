#include "DataCollector.h"

HRESULT DataCollector::Init()
{
	return S_OK;
}

void DataCollector::Release()
{

}

DataCollector::DataCollector()
{
}

DataCollector::~DataCollector()
{
}

void DataCollector::SetPlayerRegenPoint(FPOINT _regenPoint)
{
	playerRegenPoint = _regenPoint;
}

FPOINT DataCollector::GetPlayerRegenPoint()
{ 
	return playerRegenPoint;
}

void DataCollector::SetNexusRegenPoint(FPOINT _regenPoint)
{
	nexusRegenPoint = _regenPoint;
}

FPOINT DataCollector::GetNexusRegenPoint()
{
	return nexusRegenPoint;
}