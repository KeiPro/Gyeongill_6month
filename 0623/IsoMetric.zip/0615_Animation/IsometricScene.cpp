#include "IsometricScene.h"

HRESULT IsometricScene::Init()
{
	ptSelected.x = 0;
	ptSelected.y = 0;

	for (int i = 0; i < ISO_TILE_Y; i++)
	{
		for (int j = 0; j < ISO_TILE_X; j++)
		{
			tiles[i][j].x = ISO_START_X 
				+ ( j * ISO_TILE_HALF_SIZE_X ) - ( i * ISO_TILE_HALF_SIZE_X );
			tiles[i][j].y = ISO_START_Y + ( ( i + j ) * ISO_TILE_HALF_SIZE_Y );
			tiles[i][j].rc = GetRectToCenter(tiles[i][j].x, tiles[i][j].y, ISO_TILE_SIZE_X, ISO_TILE_SIZE_Y);
		}
	}

	return S_OK;
}

void IsometricScene::Release()
{
}

void IsometricScene::Update()
{
	int ratioX, ratioY;

	for (int i = 0; i < ISO_TILE_Y; i++)
	{
		for (int j = 0; j < ISO_TILE_X; j++)
		{
			// ��ġ�� Ÿ�� ��Ʈ Ȯ��
			if (PtInRect(&tiles[i][j].rc, g_ptMouse))
			{
				// 3, 4�и� Ȯ��
				if (g_ptMouse.y > tiles[i][j].y)
				{
					// 4�и� Ȯ��
					if (g_ptMouse.x > tiles[i][j].x)
					{
						// �밢�� �������� Ȯ��
						ratioX = ( g_ptMouse.x - tiles[i][j].x ) / (float)ISO_TILE_HALF_SIZE_X * 100; //�ۼ�Ʈ�� ǥ��
						ratioY = ( g_ptMouse.y - tiles[i][j].y ) / (float)ISO_TILE_HALF_SIZE_Y * 100; //�ۼ�Ʈ�� ǥ��
					
						if (ratioX + ratioY < 100)
						{
							// ���õǾ���.
							ptSelected.x = j;
							ptSelected.y = i;
						}
					}

					//3�и� Ȯ��
					else if (g_ptMouse.x < tiles[i][j].x)
					{
						ratioX = (tiles[i][j].x - g_ptMouse.x) / (float)ISO_TILE_HALF_SIZE_X * 100;
						ratioY = (g_ptMouse.y - tiles[i][j].y) / (float)ISO_TILE_HALF_SIZE_Y * 100;

						if (ratioX + ratioY < 100)
						{
							// ���õǾ���.
							ptSelected.x = j;
							ptSelected.y = i;
						}
					}
				}
				else
				{
					//2�и�
					if (g_ptMouse.x < tiles[i][j].x)
					{
						ratioX = (tiles[i][j].x - g_ptMouse.x) / (float)ISO_TILE_HALF_SIZE_X * 100;
						ratioY = (tiles[i][j].y - g_ptMouse.y) / (float)ISO_TILE_HALF_SIZE_Y * 100;

						if (ratioX + ratioY < 100)
						{
							// ���õǾ���.
							ptSelected.x = j;
							ptSelected.y = i;
						}
					}
					else //1�и�
					{
						ratioX = ( g_ptMouse.x - tiles[i][j].x ) / (float)ISO_TILE_HALF_SIZE_X * 100;
						ratioY = (tiles[i][j].y - g_ptMouse.y) / (float)ISO_TILE_HALF_SIZE_Y * 100;

						if (ratioX + ratioY < 100)
						{
							// ���õǾ���.
							ptSelected.x = j;
							ptSelected.y = i;
						}
					}
				}
			}
		}
	}

}

void IsometricScene::Render(HDC hdc)
{
	PatBlt(hdc, 0, 0, WINSIZE_X, WINSIZE_Y, WHITENESS);

	for (int i = 0; i < ISO_TILE_Y; i++)
	{
		for (int j = 0; j < ISO_TILE_X; j++)
		{
			Rectangle(hdc, tiles[i][j].rc.left, tiles[i][j].rc.top, tiles[i][j].rc.right, tiles[i][j].rc.bottom);
			
			MoveToEx(hdc, tiles[i][j].x, tiles[i][j].y - ISO_TILE_HALF_SIZE_Y, NULL);
			LineTo(hdc, tiles[i][j].x - ISO_TILE_HALF_SIZE_X, tiles[i][j].y);
			LineTo(hdc, tiles[i][j].x, tiles[i][j].y + ISO_TILE_HALF_SIZE_Y);
			LineTo(hdc, tiles[i][j].x + ISO_TILE_HALF_SIZE_X, tiles[i][j].y);
			LineTo(hdc, tiles[i][j].x, tiles[i][j].y - ISO_TILE_HALF_SIZE_Y);
			
			
			//RenderIsometric(hdc, tiles[i][j].x, tiles[i][j].y, ISO_TILE_SIZE_X, ISO_TILE_SIZE_Y);
		}
	}

	char szText[128];
	sprintf_s(szText, "���콺 ��ġ :  [%d, %d]", g_ptMouse.x, g_ptMouse.y);
	TextOut(hdc, WINSIZE_X - 250, 80, szText, strlen(szText));

	sprintf_s(szText, "���� �ε��� :  [%d, %d]", ptSelected.x, ptSelected.y);
	TextOut(hdc, WINSIZE_X - 250, 120, szText, strlen(szText));
}

IsometricScene::IsometricScene()
{
}

IsometricScene::~IsometricScene()
{
}
