#include "Battle.h"
#include "Map.h"
#include "Player.h"
#include "Nexus.h"
#include "Image.h"
#include "Animation.h"

HRESULT Battle::Init()
{
	mapBg = ImageManager::GetSingleton()->AddImage("�ʹ��", "Image/MapBackground.bmp", WINSIZE_X - 432, WINSIZE_Y);
	waterTile = ImageManager::GetSingleton()->AddImage("���ִ�", "Image/WaterAni.bmp", 0, 0, 24, 8, 3, 1, true);
	grassTile = ImageManager::GetSingleton()->AddImage("Ǯ", "Image/TileGrass.bmp", 8, 8, true);
	

	waterAni = new Animation();
	waterAni->Init(waterTile->GetWidth(), waterTile->GetHeight(), waterTile->GetFrameWidth(), waterTile->GetFrameHeight());
	waterAni->SetUpdateTime(FPS / 10);
	waterAni->SetPlayFrame(true, true);
	waterAni->Start();

	map = new Map();
	map->Init();

	player = new Player();
	player->Init();

	nexus = new Nexus();
	nexus->Init();
	DataCollector::GetSingleton()->SetNexus(nexus);


	return S_OK;
}

void Battle::Release()
{
	SAFE_DELETE(waterAni);

	if (player)
	{
		player->Release();
		SAFE_DELETE(player);
	}

	if (map)
	{
		map->Release();
		SAFE_DELETE(map);
	}


	if (nexus)
	{
		nexus->Release();
		SAFE_DELETE(nexus);
	}
}

void Battle::Update()
{
	if (map)
		map->Update();

	if (player)
		player->Update();

	if (nexus)
		nexus->Update();

	if (waterAni)
		waterAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
}

void Battle::Render(HDC hdc)
{
	if (mapBg)
		mapBg->Render(hdc, 0, 0);

	if (nexus)
		nexus->Render(hdc);

	if (waterTile)
	{
		for (int i = 0; i < TILE_X * TILE_Y; i++)
		{
			if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_WATER)
			{
				waterTile->AnimationRender(hdc, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile.left + 12, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile.top + 12, waterAni, 3.0f);
			}
		}
	}

	if (map)
	{
		map->Render(hdc);
	}

	if (player)
		player->Render(hdc);

	if (grassTile)
	{
		for (int i = 0; i < TILE_X * TILE_Y; i++)
		{
			if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_GRASS)
			{
				grassTile->Render(hdc, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile.left, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile.top, 3.0f);
			}
		}
	}

}

Battle::Battle()
{
}

Battle::~Battle()
{
}
