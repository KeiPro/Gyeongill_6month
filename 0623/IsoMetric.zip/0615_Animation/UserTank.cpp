#include "UserTank.h"
#include "Image.h"
#include "Animation.h"
#include "Missile.h"


HRESULT UserTank::Init()
{
	ImageManager::GetSingleton()->AddImage("�̻���", "Image/MissileSheet.bmp", 0, 0, 32, 16, 4, 1, true, RGB(0, 0, 1));
	ImageManager::GetSingleton()->AddImage("�̻�������Ʈ", "Image/ColiderEffect.bmp", 0, 0, 48, 16, 3, 1, true, RGB(0, 0, 1));
	
	tankPos = DataCollector::GetSingleton()->GetPlayerRegenPoint();
	invincibilityEffect = ImageManager::GetSingleton()->AddImage("��������Ʈ", "Image/PlayerEffectSheet.bmp", 0, 0, 32, 16, 2, 1 , true, RGB(0, 0, 1));
	tankImage = ImageManager::GetSingleton()->AddImage("������ũ", "Image/PlayerSheet.bmp", 0, 0, 32, 64, 2, 4, true, RGB(0, 0, 1));
	appearImage = ImageManager::GetSingleton()->AddImage("��������Ʈ", "Image/AppearImg.bmp", 0, 0, 64, 16, 4, 1, true, RGB(0, 0, 1));

	isMove = false;
	moveValue = 0;

	// Ű�� ���ȴ���, ���� �ߴ����� �ʱ�ȭ �ϴ� �Լ�.
	isKeyDown = false;
	isAppear = false;
	isInvincibility = true;

	//��ũ ����.
	speed =200.0f;
	tankSize = tankImage->GetFrameWidth() * 3.0f - 10;
	tankRect = { 0 };
	DataCollector::GetSingleton()->SetRectPlayer(&tankRect);

	// �����ӿ� ���� FrameX, FrameY ��
	currentKeyFrameX = 0;
	currentKeyFrameY = 0;
	elapsedTime = 0; 

	// ���� �� �� ��¦ �Ÿ��� �ð�
	appearTimer = 0; 

	// ���� �ð�
	invincTimer = 0;

	// appearAnimation (���� �ִϸ��̼�) �ʱ� ����.
	appearAnimation = new Animation(); 
	appearAnimation->Init(appearImage->GetWidth(), appearImage->GetHeight(), appearImage->GetFrameWidth(), appearImage->GetFrameHeight());
	appearAnimation->SetUpdateTime(FPS / 2);
	appearAnimation->SetPlayFrame(true, true);


	// invincibilityAnimation ( ���� �ִϸ��̼� ) �ʱ� ����.
	invincibilityAnimation = new Animation();
	invincibilityAnimation->Init(invincibilityEffect->GetWidth(), invincibilityEffect->GetHeight(), invincibilityEffect->GetFrameWidth(), invincibilityEffect->GetFrameHeight());
	invincibilityAnimation->SetUpdateTime(FPS / 3);
	invincibilityAnimation->SetPlayFrame(false, true);

	// �⺻������ �ִϸ��̼� ����.
	appearAnimation->Start();
	invincibilityAnimation->Start();


	firePoint.x = tankPos.x - 3;
	firePoint.y = tankPos.y - tankSize / 2;
	missileCount = 10;
	missiles = new Missile[missileCount];

	return S_OK;
}

void UserTank::Release()
{
	SAFE_DELETE(invincibilityAnimation);
	SAFE_DELETE(appearAnimation);
	SAFE_DELETE(moveAnimation);
}

void UserTank::Update()
{
	//���� �÷��̾���� �浹 ó��
	

	if (missiles)
	{
		for (int i = 0; i < missileCount; i++)
		{
			if (missiles[i].GetIsFired() == true)
				missiles[i].Update();
		}
	}

	if (isAppear == false)
	{
		appearTimer += TimeManager::GetSingleton()->GetDeltaTime();

		//1�ʰ� �Ǹ�
		if (appearTimer >= 1.0f) isAppear = true;

		if (appearAnimation)
			appearAnimation->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}
	else
	{
		// ����Ű Ű���尡 ������ �� ��ũ currentFrameX ��ȭ.
		if (isKeyDown == true)
		{
			elapsedTime++;

			if (elapsedTime % 3 == 0)
			{
				elapsedTime = 0;
				currentKeyFrameX++;

				if (currentKeyFrameX > 1)
					currentKeyFrameX = 0;
			}
		}

		// �������°� true�̸� animation���.
		if (isInvincibility == true)
		{
			invincTimer += TimeManager::GetSingleton()->GetDeltaTime();

			if (invincTimer >= 2.0f) isInvincibility = false;

			if (invincibilityAnimation)
				invincibilityAnimation->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
		}

		//Ű���� �Է� if�� �ڵ�
		if (KeyManager::GetSingleton()->IsStayKeyDown(VK_UP)) 
		{
			firePoint.x = tankPos.x - 3;
			firePoint.y = tankPos.y - tankSize / 2;

			tankPos.y -= speed * TimeManager::GetSingleton()->GetDeltaTime();
			
			currentKeyFrameY = 0;
			isKeyDown = true;
		}
		else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LEFT))
		{
			firePoint.x = tankPos.x - tankSize / 2;
			firePoint.y = tankPos.y;

			tankPos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();//24;/**/

			currentKeyFrameY = 1;
			isKeyDown = true;
		}

		else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_DOWN))
		{
			firePoint.x = tankPos.x - 3;
			firePoint.y = tankPos.y + tankSize / 2;

			tankPos.y += speed * TimeManager::GetSingleton()->GetDeltaTime();  //24;/**/

			currentKeyFrameY = 2;
			isKeyDown = true;
		}

		else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_RIGHT))
		{
			firePoint.x = tankPos.x + tankSize / 2;
			firePoint.y = tankPos.y;

			tankPos.x += speed * TimeManager::GetSingleton()->GetDeltaTime(); //24;

			currentKeyFrameY = 3;
			isKeyDown = true;
		}
		else
		{
			isKeyDown = false;
		}

		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
		{
			for (int i = 0; i < missileCount; i++)
			{
				if (missiles[i].GetIsFired() == false)
				{
					missiles[i].Init(firePoint);
					missiles[i].SetDirection(currentKeyFrameY);
					missiles[i].SetIsFired();
					break;
				}
			}
		}

		
	}

	tankRect = GetRectToCenter(tankPos.x, tankPos.y, tankSize, tankSize);

	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_WALL)
		{
			if (CheckRectCollision(tankRect, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
			{
				Collider();
				break;
			}
		}
		else if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_CEMENT)
		{
			if (CheckRectCollision(tankRect, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
			{
				Collider();
				break;
			}
		}
		else if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_WATER)
		{
			if (CheckRectCollision(tankRect, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
			{
				Collider();
				break;
			}
		}
		else if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_IRON)
		{
			if (CheckRectCollision(tankRect, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
			{
				Collider();
				break;
			}
		}
	}
	

	
}

void UserTank::Render(HDC hdc)
{
	//���� �ִϸ��̼�
	if (isAppear == false)
	{
		if (appearImage)
		{
			appearImage->AnimationRender(hdc, tankPos.x, tankPos.y, appearAnimation, 3.0f);
		}
	}
	else
	{
		if (tankImage)
		{
			//Rectangle(hdc, tankRect.left, tankRect.top, tankRect.right, tankRect.bottom);
			tankImage->FrameRender(hdc, tankPos.x, tankPos.y, currentKeyFrameX, currentKeyFrameY, 3.0f);
		}

		if (isInvincibility == true)
		{
			if (invincibilityEffect)
			{
				invincibilityEffect->AnimationRender(hdc, tankPos.x, tankPos.y, invincibilityAnimation, 3.0f);
				//FrameRender(hdc, tankPos.x, tankPos.y, invincibilityKeyFrameX, invincibilityKeyFrameY, 3.0f);
			}
		}
	}
	
	if (missiles)
	{
		for (int i = 0; i < missileCount; i++)
		{
			if (missiles[i].GetIsFired() == true)
				missiles[i].Render(hdc);
		}
	}
}

void UserTank::Collider()
{
	if (currentKeyFrameY == 0)
		tankPos.y += speed * TimeManager::GetSingleton()->GetDeltaTime();
	else if (currentKeyFrameY == 1)
		tankPos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
	else if (currentKeyFrameY == 2)
		tankPos.y -= speed * TimeManager::GetSingleton()->GetDeltaTime();
	else if (currentKeyFrameY == 3)
		tankPos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
}

UserTank::UserTank()
{
}

UserTank::~UserTank()
{
}
