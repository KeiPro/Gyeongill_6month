#include "EnemyMgr.h"

HRESULT EnemyMgr::Init()
{

	return S_OK;
}

void EnemyMgr::Release()
{
}

void EnemyMgr::Update()
{
}

void EnemyMgr::Render(HDC hdc)
{
}

EnemyMgr::EnemyMgr()
{
}

EnemyMgr::~EnemyMgr()
{
}