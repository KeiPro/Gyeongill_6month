// macroFunction.h
#pragma once
#include "pch.h"

inline void RenderLine(HDC hdc, int startX, int startY, int endX, int endY)
{
	MoveToEx(hdc, startX, startY, NULL);
	LineTo(hdc, endX, endY);
}

inline RECT GetRect(int x, int y, int size)
{
	RECT rc = { x, y, x + size, y + size };
	return rc;
}

inline RECT GetRectToCenter(int x, int y, int width, int height)
{
	RECT rc = { x - (width / 2), y - (height / 2),
		x + (width / 2), y + (height / 2) };
	return rc;
}

inline void RenderRect(HDC hdc, int x, int y, int size)
{
	MoveToEx(hdc, x, y, NULL);
	LineTo(hdc, x + size, y);
	LineTo(hdc, x + size, y + size);
	LineTo(hdc, x, y + size);
	LineTo(hdc, x, y);
}

inline void RenderIsometric(HDC hdc, int startX, int startY, int width, int height)
{
	MoveToEx(hdc, startX, startY, NULL);
	LineTo(hdc, startX - width / 2, startY + height / 2);
	LineTo(hdc, startX, startY + height);
	LineTo(hdc, startX + width / 2, startY + height / 2);
	LineTo(hdc, startX, startY);

}

inline void RenderEllipse(HDC hdc, int x, int y, int width, int height)
{
	Ellipse(hdc, x, y, x + width, y + height);
}

inline void RenderEllipseToCenter(HDC hdc, int centerX, int centerY,
	int width, int height)
{
	Ellipse(hdc, centerX - (width / 2), centerY - (height / 2),
		centerX + (width / 2), centerY + (height / 2));
}

// x, y : ������ġ
// width, height : �ʺ�, ����
inline void RenderRect(HDC hdc, int x, int y, int width, int height)
{
	Rectangle(hdc, x, y, x + width, y + height);
}

// centerX, centerY : �簢���� ����
// width, height : �ʺ�, ����
inline void RenderRectToCenter(HDC hdc, int centerX, int centerY,
	int width, int height)
{
	Rectangle(hdc, centerX - (width / 2), centerY - (height / 2),
		centerX + (width / 2), centerY + (height / 2));
}

// �浹üũ �Լ�
inline bool CheckRectCollision(RECT rc1, RECT rc2)
{
	if (rc1.left >= rc2.right ||
		rc1.right <= rc2.left ||
		rc1.top >= rc2.bottom ||
		rc1.bottom <= rc2.top)
	{
		return false;
	}
	return true;
}

inline int GetMin(int num1, int num2)
{
	if (num1 < num2)
		return num1;

	return num2;
}

inline int GetMax(int num1, int num2)
{
	if (num1 > num2)
		return num1;

	return num2;
}

inline void SetWindowSize(int x, int y, int width, int height)
{
	// ������ �۾����� ����
	RECT rc;
	rc.left = 0; rc.top = 0;
	rc.right = width; rc.bottom = height;

	// ���� ������ ũ�� �޾ƿ´�.
	AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, false);

	// �̵�
	MoveWindow(g_hWnd, x, y, rc.right - rc.left, rc.bottom - rc.top, true);
}