#include "Missile.h"
#include "Image.h"
#include "Animation.h"
#include "Nexus.h"

HRESULT Missile::Init(FPOINT firePos)
{
	pos = firePos;
	effectPos = { 0 };
	image = ImageManager::GetSingleton()->FindImage("�̻���");
	effectImg = ImageManager::GetSingleton()->FindImage("�̻�������Ʈ");
	
	effectAni = new Animation();
	effectAni->Init(effectImg->GetWidth(), effectImg->GetHeight(), effectImg->GetFrameWidth(), effectImg->GetFrameHeight());
	effectAni->SetUpdateTime(FPS / 5);
	effectAni->SetPlayFrame(false, false);
	effectAni->Start();

	size = image->GetFrameHeight() * 1.0f;
	speed = 550.0f;
	isCollision = false;
	return S_OK;
}

void Missile::Release()
{
}

void Missile::Update()
{
	if (isCollision == true)
	{
		if (effectAni->GetNowPlayIdx() == 2)
		{
			Reset();
			return;
		}
		else
			effectAni->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}

	if (isFired == true && isCollision == false)
	{
		if (currentKeyFrameX == 0)
		{
			pos.y -= speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		else if (currentKeyFrameX == 1)
		{
			pos.x -= speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		else if (currentKeyFrameX == 2)
		{
			pos.y += speed * TimeManager::GetSingleton()->GetDeltaTime();
		}
		else if (currentKeyFrameX == 3)
		{
			pos.x += speed * TimeManager::GetSingleton()->GetDeltaTime();
		}

		SetRect(&rc, pos.x - size / 2, pos.y - size / 2, pos.x + size / 2, pos.y + size / 2);

		for (int i = 0; i < TILE_X * TILE_Y; i++)
		{
			if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_WALL)
			{
				if (CheckRectCollision( rc, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
				{
					isCollision = true;
					DataCollector::GetSingleton()->GetTileInfo()[i].terrain = TR_NONE;
				}				
			}

			if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_CEMENT)
			{
				if (CheckRectCollision(rc, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
				{
					isCollision = true;
				}
			}

			if (DataCollector::GetSingleton()->GetTileInfo()[i].terrain == TR_IRON)
			{
				if (CheckRectCollision(rc, DataCollector::GetSingleton()->GetTileInfo()[i].rcTile))
				{
					isCollision = true;
				}
			}
		}
		if (CheckRectCollision(rc, DataCollector::GetSingleton()->GetNexus()->GetRect()))
		{
			isCollision = true;
			DataCollector::GetSingleton()->GetNexus()->SetCurrKeyFrame(1);
		}
	}
}

void Missile::Render(HDC hdc)
{
	if (image && isFired)
	{
		//Rectangle(hdc, pos.x - size / 2, pos.y - size / 2, pos.x + size / 2, pos.y + size / 2);
		image->FrameRender(hdc, pos.x, pos.y, currentKeyFrameX, 0, 3.0f);

		
	}
	
	if (isCollision)
	{
		effectImg->AnimationRender(hdc, pos.x, pos.y, effectAni, 3.0f);
	}
}

void Missile::Reset()
{
	isCollision = false;
	isFired = false;
	currentKeyFrameX = 0;
	rc = { 0 };
}

void Missile::SetDirection(int keyframe)
{
	currentKeyFrameX = keyframe;
}

Missile::Missile()
{
}

Missile::~Missile()
{
}
