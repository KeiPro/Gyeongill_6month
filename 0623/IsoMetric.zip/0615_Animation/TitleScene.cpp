#include "TitleScene.h"
#include "Image.h"

HRESULT TitleScene::Init()
{
	titleImage = ImageManager::GetSingleton()->AddImage("���� Ÿ��", "Image/Title.bmp",WINSIZE_X, WINSIZE_Y);
	titleSelectImage = ImageManager::GetSingleton()->AddImage("����Ʈ��ũ", "Image/TitleSelectTank.bmp", 50, 50, true, RGB(0, 0, 1));
	selectIdx = 0;

	return S_OK;
}

void TitleScene::Release()
{

}

void TitleScene::Update()
{
	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_SPACE))
	{
		switch (selectIdx)
		{
		case 0:
			SceneManager::GetSingleton()->ChangeScene("��Ʋ��", "�ε�1");
			break;

		case 1:

			break;

		case 2:
			SceneManager::GetSingleton()->ChangeScene("�ʿ�����");
			break;
		}		  
	}

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_DOWN))
	{
		selectIdx++;
		if (selectIdx == 3)
			selectIdx = 0;
	}
	else if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_UP))
	{
		selectIdx--;
		if (selectIdx == -1)
			selectIdx = 2;
	}
}

void TitleScene::Render(HDC hdc)
{
	titleImage->Render(hdc, 0, 0);
	titleSelectImage->Render(hdc, 370, selectImgPosY[selectIdx]);
}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}
