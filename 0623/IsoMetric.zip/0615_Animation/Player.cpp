#include "Player.h"
#include "UserTank.h"

HRESULT Player::Init()
{
	tank = new UserTank();
	tank->Init();

	return S_OK;
}

void Player::Release()
{
	if (tank)
		tank->Release();
}

void Player::Update()
{
	if (tank)
		tank->Update();
}

void Player::Render(HDC hdc)
{
	if (tank)
		tank->Render(hdc);
}

Player::Player()
{
}

Player::~Player()
{
}
