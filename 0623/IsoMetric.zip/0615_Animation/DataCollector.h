#pragma once
#include "pch.h"
#include "SingletonBase.h"


class Nexus;
class DataCollector : public SingletonBase<DataCollector>
{
private:

	FPOINT playerRegenPoint;
	FPOINT nexusRegenPoint;
	RECT* rcPlayer;
	TILE_INFO* tileInfo;
	Nexus* nexus;

public:

	HRESULT Init();
	void Release();

	void SetPlayerRegenPoint(FPOINT _regenPoint);
	FPOINT GetPlayerRegenPoint();

	void SetNexusRegenPoint(FPOINT _regenPoint);
	FPOINT GetNexusRegenPoint();

	void SetRectPlayer(RECT* rc) { rcPlayer = rc; }
	RECT GetRectPlayer() { return *rcPlayer; }

	void SetTileInfo(TILE_INFO* _tileinfo) { tileInfo = _tileinfo; }
	TILE_INFO* GetTileInfo() { return tileInfo; }

	void SetNexus(Nexus* nexus) { this->nexus = nexus; }
	Nexus* GetNexus() { return nexus; }
	DataCollector();
	~DataCollector();
};

