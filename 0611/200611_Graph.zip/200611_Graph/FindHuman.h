#pragma once

class Graph;
class FindHuman
{
private:
	Graph* g;

public:

	void FindMethod();
	void CheckHuman(std::vector<PEOPLE_INFO>& vecPeople);
	


	FindHuman();
	~FindHuman();
};

