#include "pch.h"
#include "FindHuman.h"
#include "Graph.h"


FindHuman::FindHuman()
{
}


FindHuman::~FindHuman()
{
}

void FindHuman::FindMethod()
{
	FILE* fp = NULL;

	fopen_s(&fp, "����2.txt", "r");

	int peopleCount;
	fscanf_s(fp, "%d", &peopleCount);

	vector<PEOPLE_INFO> vecPeople(peopleCount);

	while (true)
	{
		if (feof(fp))
			break;

		int id;
		fscanf_s(fp, "%d", &id);

		vecPeople[id - 1].id = id;

		int answerCount;
		fscanf_s(fp, "%d", &answerCount);

		vecPeople[id - 1].vecAnswer.resize(answerCount);

		int answer;
		for (int i = 0; i < answerCount; ++i)
		{
			fscanf_s(fp, "%d", &answer);

			vecPeople[id - 1].vecAnswer[i] = answer;
		}
	}

	fclose(fp);

	g = new Graph();

	CheckHuman(vecPeople);

	int humanCount = 0;
	for (PEOPLE_INFO stPeople : vecPeople)
	{
		if (stPeople.isHuman)
			++humanCount;
	}

	cout << humanCount << endl;

	delete g;
}

void FindHuman::CheckHuman(vector<PEOPLE_INFO>& vecPeople)
{
	g->DFS(vecPeople, 60000, 41609);
	//g->BFS(vecPeople, 60000, 1);
}

