﻿// 200611_Graph.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include "Graph.h"
#include "FindHuman.h"

int main()
{
	FindHuman fh;
	
	fh.FindMethod();

	//// 인접행렬
	//int** matrix = nullptr;
	//int nodeCount;

	//Graph g;
	//nodeCount = g.CreateMatrix(matrix);

	//if (matrix)
	//{
	//	for (int i = 0; i < nodeCount; i++)
	//	{
	//		delete matrix[i];
	//	}
	//	delete matrix;
	//}

	//// 인접리스트
	//vector<int>* list = nullptr;
	//nodeCount = g.CreateList(&list);

	//// 너비우선탐색
	//g.BFS(list, nodeCount, 4);

	//if (list)
	//{
	//	delete[] list;
	//}
}