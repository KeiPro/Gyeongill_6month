#include "pch.h"
#include "Graph.h"



int Graph::CreateMatrix(int ** matrix)
{
	int node = 5, edge = 6;

	matrix = new int*[node];
	for (int i = 0; i < node; i++)
	{
		matrix[i] = new int[node];
	}

	// �ʱ�ȭ
	for (int i = 0; i < node; i++)
	{
		for (int j = 0; j < node; j++)
		{
			if (i == j)	matrix[i][j] = 0;
			else		matrix[i][j] = I;
		}
	}
	// 1������ ����� ���
	matrix[0][1] = 1;	matrix[1][0] = 1;
	matrix[0][2] = 1;	matrix[2][0] = 1;
	matrix[0][3] = 1;	matrix[3][0] = 1;
	// 2������ ����� ���
	matrix[1][2] = 1;	matrix[2][1] = 1;
	// 3������ ����� ���
	matrix[2][4] = 1;	matrix[4][2] = 1;
	// 4������ ����� ���
	matrix[3][4] = 1;	matrix[4][3] = 1;

	//Ȯ��
	for (int i = 0; i < node; i++)
	{
		for (int j = 0; j < node; j++)
		{
			cout << matrix[i][j] << '\t';
		}
		cout << endl;
	}
	cout << endl;

	return node;
}

int Graph::CreateList(vector<int>** list)
{
	int node = 5, edge = 6;

	(*list) = new vector<int>[node];
	// 1�� ���� ����� ���
	(*list)[0].push_back(1);	(*list)[0].push_back(2);	(*list)[0].push_back(3);
	// 2�� ���� ����� ���
	(*list)[1].push_back(0);	(*list)[1].push_back(2);
	// 3�� ���� ����� ���
	(*list)[2].push_back(0);	(*list)[2].push_back(1);	(*list)[2].push_back(4);
	// 4�� ���� ����� ���
	(*list)[3].push_back(0);	(*list)[3].push_back(4);
	// 5�� ���� ����� ���
	(*list)[4].push_back(2);	(*list)[4].push_back(3);

	// Ȯ��
	for (int i = 0; i < node; i++)
	{
		cout << i << " : ";
		for (int j = 0; j < (*list)[i].size(); j++)
		{
			cout << (*list)[i][j] << '\t';
		}
		cout << endl;
	}
	cout << endl;

	return node;
}

void Graph::BFS(vector<int>* list, int listSize, int startIndex)
{
	queue<int> q;
	bool* isVisited = new bool[listSize];
	memset(isVisited, 0, sizeof(bool) * listSize);

	q.push(startIndex);
	isVisited[startIndex] = true;

	while (!q.empty())
	{
		int currIndex = q.front();
		q.pop();

		cout << currIndex << endl;

		for (int i = 0; i < list[currIndex].size(); i++)
		{
			int connectNode = list[currIndex][i];

			if (isVisited[connectNode] == false)
			{
				q.push(connectNode);
				isVisited[connectNode] = true;
			}
		}
	}
}

void Graph::DFS(vector<PEOPLE_INFO>& vecPeople, int listSize, int startIndex)
{
	stack<int> s;
	bool* isVisited = new bool[listSize]; //�湮 �ߴ��� ���ߴ����� Ȯ��

	memset(isVisited, 0, sizeof(bool) * listSize);

	s.push(startIndex-1);
	isVisited[startIndex-1] = true;
	vecPeople[startIndex-1].isHuman = true;
	int currIndex = s.top();

	while (!s.empty())
	{
		s.pop();
		for (int i = 0; i < vecPeople[currIndex].vecAnswer.size(); i++)
		{
			int connectNode = vecPeople[currIndex].vecAnswer[i];

			if (isVisited[connectNode-1] == false)
			{
				s.push(connectNode-1);
				isVisited[connectNode-1] = true;
			}
		}

		if (!s.empty())
		{
			currIndex = s.top();
			vecPeople[currIndex].isHuman = true;
		}
	}

	//count = count;


	//stack<int> s;
	//bool* isVisited = new bool[listSize]; //�湮 �ߴ��� ���ߴ����� Ȯ��
	//memset(isVisited, 0, sizeof(bool) * listSize);
	//s.push(startIndex - 1);
	//isVisited[startIndex - 1] = true;
	//vecPeople[startIndex - 1].isHuman = true;
	//int currIndex = s.top();
	//while (!s.empty())
	//{
	//	for (int i = 0; i < vecPeople[currIndex].vecAnswer.size(); i++)
	//	{
	//		int connectNode = vecPeople[currIndex].vecAnswer[i];

	//		if (isVisited[connectNode-1] == false)
	//		{
	//			s.push(connectNode-1);
	//			isVisited[connectNode-1] = true;
	//			vecPeople[currIndex].isHuman = true;
	//		}
	//	}

	//	if (!s.empty())
	//	{
	//		currIndex = s.top();
	//	}
	//}
}

Graph::Graph()
{
}


Graph::~Graph()
{
}
