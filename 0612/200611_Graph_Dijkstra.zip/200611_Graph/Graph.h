#pragma once
#include "pch.h"


class Graph
{
public:
	int CreateMatrix(int*** matrix);
	int CreateMatrix(int** matrix);
	int CreateList(vector<int>** list);

	// �ʺ�켱Ž��
	void BFS(vector<int>* list, int listSize, int startIndex);
	void DFS(vector<PEOPLE_INFO>& vecPeople, int listSize, int startIndex);

	//��� ����Լ�
	void CostCalculate( int startIndex, int destIndex, int*** matrix);



	Graph();
	~Graph();
};

