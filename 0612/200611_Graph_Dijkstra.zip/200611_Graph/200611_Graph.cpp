﻿// 200611_Graph.cpp : 이 파일에는 'main' 함수가 포함됩니다. 거기서 프로그램 실행이 시작되고 종료됩니다.
//

#include "pch.h"
#include "Graph.h"
#include "FindHuman.h"
#include "Dijkstra.h"

int main()
{
	
	
	// 인접행렬
	int** matrix = nullptr;
	int nodeCount;

	Graph g;
	nodeCount = g.CreateMatrix(&matrix);

	Dijkstra dijkstra;
	dijkstra.FindPath(&matrix, nodeCount, 1, 7);
	dijkstra.PrintPath();

	if (matrix)
	{
		for (int i = 0; i < nodeCount; i++)
		{
			delete matrix[i];
		}
		delete matrix;
	}




	//FindHuman fh;
	//
	//fh.FindMethod();

	

	//// 인접리스트
	//vector<int>* list = nullptr;
	//nodeCount = g.CreateList(&list);

	//// 너비우선탐색
	//g.BFS(list, nodeCount, 4);

	//if (list)
	//{
	//	delete[] list;
	//}

	//// 다익스트라 알고리즘

	//인접 행렬
	/*int** matrix = nullptr;
	int nodeCount;

	Graph g;
	nodeCount = g.CreateMatrix(&matrix);
	

	g.CostCalculate(1, 7, &matrix);*/

	////확인
	//for (int i = 0; i < nodeCount; i++)
	//{
	//	for (int j = 0; j < nodeCount; j++)
	//	{
	//		cout << matrix[i][j] << '\t';
	//	}
	//	cout << endl;
	//}
	//cout << endl;
}