#include "pch.h"
#include "Dijkstra.h"

void Dijkstra::FindPath(int *** matrix, int nodeCount, int start, int dest)
{
	vector<int> vec;
	vec.resize(nodeCount);
	int prev = 0;

	if (costToNode)  { delete[] costToNode; }
	if (prevNodeId)	 { delete[] prevNodeId; }
	if (isUpdated)	 { delete[] isUpdated; }

	costToNode = new int[nodeCount];
	prevNodeId = new int[nodeCount];
	isUpdated = new bool[nodeCount];

	startNode = start;
	destNode = dest;

	// �ʱ�ȭ

	for (int i = 0; i < nodeCount; i++)
	{
		costToNode[i] = I;
		prevNodeId[i] = -1; //�ǹ̾��� ���ڸ� �־��ش�.
		isUpdated[i] = false;
	}

	// ���� ���
	costToNode[start - 1] = 0;
	int minID;
	int minCost;
	while (true)
	{
		minID = -1;
		minCost = I;

		// ���� ��� �� ����� ���� ���� ��� ��带 Ž��
		for (int i = 0; i < nodeCount; i++)
		{
			if (isUpdated[i] == true) continue;

			if (minCost > costToNode[i])
			{
				minCost = costToNode[i];
				minID = i;
			}
		}

		// �� �̻� ������ ��尡 ������ Ż��
		if (minID == -1)
			break;

		// �� ��带 ����
		for (int i = 0; i < nodeCount; i++)
		{
			if (costToNode[i] > (*matrix)[minID][i] + costToNode[minID])
			{
				costToNode[i] = (*matrix)[minID][i] + costToNode[minID];
				prevNodeId[i] = minID;
			}
		}

		// Ȯ�ο� ���
		for (int i = 0; i < nodeCount; i++)
		{
			cout << i + 1 << " : " << costToNode[i] << "\t \t [ " << prevNodeId[i]+1 << " ]" << endl;
		}
		cout << endl;

		//while(prevNodeId[i])
				
		isUpdated[minID] = true;
	}
}

void Dijkstra::PrintPath()
{
	list<int> path;

	int index = destNode - 1;

	while ( index != startNode - 1 )
	{
		path.push_front(index + 1);
		index = prevNodeId[index];
	}

	path.push_front(index+1);

	for (auto p : path)
	{
		cout << p << " -> ";
	}

	cout << "END" << endl;
}

Dijkstra::Dijkstra()
{
	costToNode = nullptr;
	prevNodeId = nullptr;
	isUpdated = nullptr;
}

Dijkstra::~Dijkstra()
{
	if (costToNode) { delete[] costToNode; }
	
	if (prevNodeId) { delete[] prevNodeId; }

	if (isUpdated) { delete[] isUpdated;	}
}
