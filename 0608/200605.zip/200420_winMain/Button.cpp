#include "Button.h"
#include "Image.h"
#include "ButtonFunction.h"



//HRESULT Button::Init(const char* imageName, int posX, int posY, POINT downFramePoint, POINT upFramePoint, /*�߰�*/void(*buttonFunc)(void))
//{
//	state = BUTTON_STATE::NONE;
//	pos.x = posX;
//	pos.y = posY;
//	btnDownFramePoint = downFramePoint;
//	btnUpFramePoint = upFramePoint;
//
//	image = ImageManager::GetSingleton()->FindImage(imageName); //Add�� �ٸ�������
//
//	rc = GetRectToCenter(pos.x, pos.y, 
//		image->GetFrameWidth(), image->GetFrameHeight());
//
//	this->buttonFunc = buttonFunc;
//	this->memberFunc = nullptr; //����ó��.
//	this->btnFunc = nullptr;
//
//	return S_OK;
//}

HRESULT Button::Init(const char* imageName, int posX, int posY, POINT downFramePoint, POINT upFramePoint)
	///*�߰�*/void(ButtonFunction::*memberFunc)(const char*), ButtonFunction* btnFunc, const char* sceneName)
{
	state = BUTTON_STATE::NONE;
	pos.x = posX;
	pos.y = posY;
	btnDownFramePoint = downFramePoint;
	btnUpFramePoint = upFramePoint;

	image = ImageManager::GetSingleton()->FindImage(imageName); //Add�� �ٸ�������

	rc = GetRectToCenter(pos.x, pos.y,
		image->GetFrameWidth(), image->GetFrameHeight());

	this->buttonFunc = nullptr; //����ó��
	/*this->memberFunc = memberFunc;
	this->btnFunc = btnFunc;
	this->sceneName = sceneName;*/

	return S_OK;
}

void Button::Release()
{
}

void Button::Update()
{
	if (PtInRect(&rc, g_ptMouse)) //Point�� Rect�ȿ� �������� True�� ��ȯ�ؼ� �Ʒ��� ����ȴ�.
	{
		if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON))
		{
			state = BUTTON_STATE::DOWN;
			//SceneManager::GetSingleton()->ChangeScene("��Ʋ", "�ε�1");
		}
		else if (KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON) && state == BUTTON_STATE::DOWN)
		{
			state = BUTTON_STATE::UP;

			if (buttonFunc)			buttonFunc();
			else if (btnFunc && memberFunc)
				(btnFunc->*memberFunc)(args->sceneName, args->loadingName); //�θ��� ��ü�� �־���Ѵ�. 
		}
	}
	else
	{
		state = BUTTON_STATE::NONE;
	}
}

void Button::Render(HDC hdc)
{
	switch (state)
	{
	case BUTTON_STATE::DOWN:
		if (image)
			image->FrameRender(hdc, pos.x, pos.y, btnDownFramePoint.x, btnDownFramePoint.y);
		break;

	case BUTTON_STATE::NONE:
	case BUTTON_STATE::UP:

		if (image)
			image->FrameRender(hdc, pos.x, pos.y, btnUpFramePoint.x, btnUpFramePoint.y);

		break;
	}

	//RenderRectToCenter(hdc, pos.x, pos.y, image->GetFrameWidth(), image->GetFrameHeight());
}

void Button::SetButtonFunc(ButtonFunction * bf, void(ButtonFunction::* btnFunc)(const char *, const char *), ARGUMENT_INFO * args)
{
	this->memberFunc = btnFunc;			// �Լ� ȣ�� ��ü
	this->btnFunc = bf;					// ȣ��Ǵ� ����Լ�
	//this->sceneName = sceneName;
	this->args = args;					// �Ű�����
}

Button::Button()
{
}

Button::~Button()
{
}

