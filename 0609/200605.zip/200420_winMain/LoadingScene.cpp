#include "LoadingScene.h"
#include "Image.h"
#include "Animation.h"

HRESULT LoadingScene::Init()
{
	
	bg = ImageManager::GetSingleton()->AddImage("loading", "Image/LoadingCircleOld.bmp", 0, 0, 816, 102, 8, 1, true, RGB(255,255,255));
	
	ani = new Animation();
	ani->Init(bg->GetWidth(), bg->GetHeight(), bg->GetFrameWidth(), bg->GetFrameHeight());
	ani->SetUpdateTime(FPS / 3.0f);
	ani->SetPlayFrame(false, true);
	ani->Start();

	return S_OK;

}

void LoadingScene::Release()
{
	SAFE_DELETE(ani);
}

void LoadingScene::Update()
{
	if (ani)
	{
		ani->UpdateKeyFrame(TimeManager::GetSingleton()->GetDeltaTime());
	}
}

void LoadingScene::Render(HDC hdc)
{
	//if(bg) bg->Render(hdc, 0, 0);
	bg->AnimationRender(hdc, WINSIZE_X / 2, WINSIZE_Y/2, ani);
}

LoadingScene::LoadingScene()
{
}

LoadingScene::~LoadingScene()
{
}
