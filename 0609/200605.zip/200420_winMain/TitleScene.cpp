#include "TitleScene.h"
#include "Image.h"
#include "Button.h"
#include "ButtonFunction.h"

static void click1()
{
	SceneManager::GetSingleton()->ChangeScene("��Ʋ", "�ε�1");
}
static void click2()
{
	if (MessageBox(g_hWnd, "�޽���", "�޽���ĸ��", MB_YESNO) == IDYES)
	{
		PostQuitMessage(0);
	}
	else
	{

	}
}


HRESULT TitleScene::Init()
{
	bg = ImageManager::GetSingleton()->AddImage("titleBG", "Image/bin.bmp", WINSIZE_X, WINSIZE_Y);


	SoundManager::GetSingleton()->AddSound("Dark Waltz.mp3", "Sound/Dark Waltz.mp3", true, true);
	
	ImageManager::GetSingleton()->AddImage("�Ϲݹ�ư", "Image/button.bmp", 0.0f, 0.0f, 122, 62, 1, 2);

	btnFunc = new ButtonFunction();

	POINT upFramePoint = { 0, 0 };
	POINT downFramePoint = { 0, 1 };

	button1 = new Button();
	button1->Init("�Ϲݹ�ư", 150, 100, downFramePoint, upFramePoint /*ButtonFunction::ChangeScene*/ /*&ButtonFunction::ChangeScene1, btnFunc*/); //��Ʋ ������ �̵�

	args = new ARGUMENT_INFO();
	args->sceneName = "��Ʋ";
	args->loadingName = "�ε�1";
	button1->SetButtonFunc(btnFunc, &(ButtonFunction::ChangeScene1), args);

	button2 = new Button();
	button2->Init("�Ϲݹ�ư", 450, 100, downFramePoint, upFramePoint); //���α׷� �����Ұ����� -> ok, cancle �Ȳ����Բ�..

	args1 = new ARGUMENT_INFO();
	args1->sceneName = "Ÿ�ϸ���";
	args1->loadingName = "�ε�1";
	button2->SetButtonFunc(btnFunc, &(ButtonFunction::ChangeScene1), args1);
	

	return S_OK;
}

void TitleScene::Release()
{
	SAFE_DELETE(args);
	SAFE_DELETE(args1);

	button1->Release();
	SAFE_DELETE(button1);

	button2->Release();
	SAFE_DELETE(button2);

	SAFE_DELETE(btnFunc);
}

void TitleScene::Update()
{
	SoundManager::GetSingleton()->Update();

	if (button1)		button1->Update();
	if (button2)		button2->Update();

	//if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_RETURN))
	//{
	//	SceneManager::GetSingleton()->ChangeScene("��Ʋ", "�ε�1");

	//	return;
	//}
}

void TitleScene::Render(HDC hdc)
{
	if (bg)
	{
		bg->Render(hdc, 0, 0);
	}

	if (button1)		button1->Render(hdc);
	if (button2)		button2->Render(hdc);

}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}
