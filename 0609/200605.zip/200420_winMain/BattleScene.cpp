#include "BattleScene.h"
#include "Image.h"
#include "Tank.h"
#include "Missile.h"
#include "Enemy.h"
#include "EnemyManager.h"
#include "Image.h"
#include "KofPlayer.h"
#include "SpaceShip.h"
#include "Camel.h"

HRESULT BattleScene::Init()
{
	bg = ImageManager::GetSingleton()->AddImage("BattleBG", "Image/background.bmp", WINSIZE_X, WINSIZE_Y);

	SoundManager::GetSingleton()->AddSound("Dark Waltz.mp3", "Sound/Dark Waltz.mp3", true, true);

	// ��Ÿ
	camel = new Camel();
	camel->Init();

	// ���ּ�
	spaceShip = new SpaceShip();
	spaceShip->Init();

	// ��
	enemyMgr = new EnemyManager();
	enemyMgr->Init();

	Sleep(2000); //loading�� ���� 2�� �߰�.

	return S_OK;
}

void BattleScene::Release()
{
	camel->Release();
	SAFE_DELETE(camel);

	spaceShip->Release();
	SAFE_DELETE(spaceShip);

	enemyMgr->Release();
	SAFE_DELETE(enemyMgr);
}

void BattleScene::Update()
{
	SoundManager::GetSingleton()->Update();

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_RETURN))
	{
		SceneManager::GetSingleton()->ChangeScene("Ÿ��Ʋ");

		return;
	}

	if (camel)
	{
		camel->Update();
	}

	if (spaceShip)
	{
		spaceShip->Update();
	}

	if (enemyMgr)
	{
		enemyMgr->Update();
	}
}

void BattleScene::Render(HDC hdc)
{
	if (bg)
	{
		bg->Render(hdc, 0, 0);
	}
	
	if (camel)
	{
		camel->Render(hdc);
	}

	if (enemyMgr)
	{
		enemyMgr->Render(hdc);
	}


	if (spaceShip)
	{
		spaceShip->Render(hdc);
	}
}

BattleScene::BattleScene()
{
}

BattleScene::~BattleScene()
{
}
