#include "TitleScene.h"
#include "Image.h"

HRESULT TitleScene::Init()
{
	bg = ImageManager::GetSingleton()->AddImage("titleBG", "Image/bin.bmp", WINSIZE_X, WINSIZE_Y);


	SoundManager::GetSingleton()->AddSound("Dark Waltz.mp3", "Sound/Dark Waltz.mp3", true, true);
	
	return S_OK;
}

void TitleScene::Release()
{
}

void TitleScene::Update()
{
	SoundManager::GetSingleton()->Update();

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_RETURN))
	{
		SceneManager::GetSingleton()->ChangeScene("��Ʋ", "�ε�1");

		return;
	}
}

void TitleScene::Render(HDC hdc)
{
	if (bg)
	{
		bg->Render(hdc, 0, 0);
	}

}

TitleScene::TitleScene()
{
}

TitleScene::~TitleScene()
{
}
