﻿#include "pch.h"
#include <iostream>
#include "PatternContext.h"
#include "StrategyPattern.h"

int main()
{
	PatternContext testObject;

	StrategyInterface* testFunction1 = new ConcreateStrategyA();
	StrategyInterface* testFunction2 = new ConcreateStrategyB();
	StrategyInterface* testFunction3 = new ConcreateStrategyC();

	testObject.ChangeStrategy(testFunction1);
	testObject.ContextInterface();	
	
	testObject.ChangeStrategy(testFunction2);
	testObject.ContextInterface();

	testObject.ChangeStrategy(testFunction3);
	testObject.ContextInterface();
}

// 똑같은 이름을 가진 함수를 가지고 다른 동작을 하게 하려면 오버로딩이나 오버라이딩이 있었지.

// 순수 가상 함수 인터페이스를 통해 함수 자체를 바꾸는거야 함수 자체를 다른 기능을 하는 기능으로 바꿔서 동작하게 하는 거야.
// 두 가지가 있다.
// 1. 순수 가상 함수를 써서
// 2. 함수 포인터를 써서.. 

//오늘은 순수 가상함수를 통해 만들어보는걸 해보자.