#include "TilemapToolScene.h"
#include "Image.h"
#include "macroFunction.h"
#include <shobjidl_core.h>

HRESULT TilemapToolScene::Init()
{
	SetWindowSize(WINSTART_X, WINSTART_Y, WINSIZE_TILE_MAP_X, WINSIZE_TILE_MAP_Y);

	sampleTileImage = ImageManager::GetSingleton()->AddImage("���� Ÿ��", "Image/maptiles.bmp", 0, 0, 640, 288, SAMPLE_TILE_X, SAMPLE_TILE_Y);
	objectTileImage = ImageManager::GetSingleton()->AddImage("������ƮŸ��", "Image/tilemapObject1.bmp", 0, 0, 96, 288, OBJECT_TILE_X, OBJECT_TILE_Y, true, RGB(255, 255, 255));
	saveImage = ImageManager::GetSingleton()->AddImage("SaveRectImage", "Image/save.bmp", 200, 80, true, RGB(255,255,255));
	loadImage = ImageManager::GetSingleton()->AddImage("LoadRectImage", "Image/load.bmp", 200, 80, true, RGB(255,255,255));
	typeImage = ImageManager::GetSingleton()->AddImage("TypeRectImage", "Image/type.bmp", 200, 80, true, RGB(255,255,255));
	 
	sampleTileType = SAMPLE_TILE_TYPE::SAMPLE;

	//sampleTileRect = { WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth(), 0,  WINSIZE_TILE_MAP_X, sampleTileImage->GetHeight() };
	//DestTileRect = {0, 0, };

	// ������ Ÿ�� 
	selectTileInfo.frameX = 0;
	selectTileInfo.frameY = 0;
	selectTileInfos[0].frameX = 0;
	selectTileInfos[0].frameY = 0;
	selectTileInfos[1].frameX = 0;
	selectTileInfos[2].frameY = 0;

	minX = minY = maxX = maxY = 0;
	dragSizeX = dragSizeY = 0;

	isDownSampleArea = false;

	rcType = GetRectToCenter(WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth() + 80,
		660, 200, 80);

	rcSave = GetRectToCenter(rcType.right + 100,
		660, 200, 80);

	rcLoad = GetRectToCenter( rcSave.right + 100,  //WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth() + 200,
		660, 200, 80);

	// �����ʿ� ���� Ÿ���� Rect�� �����Ѵ�.
	for (int i = 0; i < SAMPLE_TILE_Y; i++)
	{
		for (int j = 0; j < SAMPLE_TILE_X; j++)
		{
			sampleTileInfo[i * SAMPLE_TILE_X + j].frameX = j;
			sampleTileInfo[i * SAMPLE_TILE_X + j].frameY = i;
			
			//��Ʈ���� �������ִ� �Լ�
			SetRect(&sampleTileInfo[i * SAMPLE_TILE_X + j].rcTile,
				WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth() + j * TILE_SIZE,
				0 + i * TILE_SIZE,
				WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth() + j * TILE_SIZE + TILE_SIZE,
				0 + i * TILE_SIZE + TILE_SIZE);
		}
	}

	// �����ʿ� ������Ʈ Ÿ���� Rect�� �����Ѵ�.
	for (int i = 0; i < OBJECT_TILE_Y; i++)
	{
		for (int j = 0; j < OBJECT_TILE_X; j++)
		{
			objectTileInfo[i * OBJECT_TILE_X + j].frameX = j;
			objectTileInfo[i * OBJECT_TILE_X + j].frameY = i;

			//��Ʈ���� �������ִ� �Լ�
			SetRect(&objectTileInfo[i * OBJECT_TILE_X + j].rcTile,
				WINSIZE_TILE_MAP_X - objectTileImage->GetWidth() + j * TILE_SIZE,
				0 + i * TILE_SIZE,
				WINSIZE_TILE_MAP_X - objectTileImage->GetWidth() + j * TILE_SIZE + TILE_SIZE,
				0 + i * TILE_SIZE + TILE_SIZE);
		}
	}

	// ���ʿ� ���� Ÿ�� Rect�� �����Ѵ�.
	for (int i = 0; i < TILE_Y; i++)
	{
		for (int j = 0; j < TILE_X; j++)
		{
			SetRect(&tileInfo[i * TILE_X + j].rcTile,
				j * TILE_SIZE,
				0 + i * TILE_SIZE,
				j * TILE_SIZE + TILE_SIZE,
				0 + i * TILE_SIZE + TILE_SIZE);
		}
	}

	// ���ʿ� �׷��� ������ �ʱ�ȭ�Ѵ�. ( �⺻������ �ܵ� ���� )
	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		tileInfo[i].frameX = 3;
		tileInfo[i].frameY = 0;
		tileInfo[i].terrain = TR_GRASS;
		tileInfo[i].tileType = SAMPLE_TILE_TYPE::SAMPLE;
	}

	return S_OK;
}

void TilemapToolScene::Release()
{
}

void TilemapToolScene::Update()
{
	//if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON) && PtInRect(&sampleTileRect, g_ptMouse))
	//{
	//	// �����ʿ� ���� Ÿ���� Rect�� �����Ѵ�.
	//	for (int i = 0; i < SAMPLE_TILE_Y; i++)
	//	{
	//		for (int j = 0; j < SAMPLE_TILE_X; j++)
	//		{
	//			if (PtInRect(&sampleTileInfo[i * SAMPLE_TILE_X + j].rcTile, g_ptMouse))
	//			{
	//				selectTileInfo.frameX = sampleTileInfo[i * SAMPLE_TILE_X + j].frameX;
	//				selectTileInfo.frameY = sampleTileInfo[i * SAMPLE_TILE_X + j].frameY;
	//			}
	//		}
	//	}
	//}

	////if(KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON) && )
	//
	//// ���ʿ� �׷��� ������ �ʱ�ȭ�Ѵ�. ( �⺻������ �ܵ� ���� )
	//for (int i = 0; i < TILE_X * TILE_Y; i++)
	//{
	//	if (PtInRect(&tileInfo[i].rcTile, g_ptMouse))
	//	{
	//		if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
	//		{
	//			tileInfo[i].frameX = selectTileInfo.frameX;
	//			tileInfo[i].frameY = selectTileInfo.frameY;
	//		}
	//	}
	//}


	// ���콺 ���� ��ư�� ������ ��
		// 1) ���� Ÿ�Ͽ��� ���õǴ� ���.
		// 2) ���� Ÿ�Ͽ��� �׷��� Ÿ���� ���õǴ� ���.

	// ���콺 ���� ��ư�� ���� ��
		// 1) ���G Ÿ�� �����ȿ��� ���� ���.
		// 2) ���� Ÿ�� �ȿ��� ���� ���.

	// ���콺�� �̵��� �� (�巡��)

	// ��ư �߰� �ؼ� �� �̻ڰ� �� �����ϰ� �����, ������Ʈ�� �ø����� ������Ʈ ������ �ʿ��ϰ���? ��ư �ϳ� �� ���� �� ��ư�� �� �� ������
	// �ͷ��� ������ ������ �� �� �� ������ ������Ʈ ���÷� �ٲ�� ����~

	if (KeyManager::GetSingleton()->IsOnceKeyDown(VK_LBUTTON))
	{		
		if (PtInRect(&rcType, g_ptMouse))
		{
			if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
				sampleTileType = SAMPLE_TILE_TYPE::OBJECT;
			else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
				sampleTileType = SAMPLE_TILE_TYPE::SAMPLE;
		}

		if (PtInRect(&rcSave, g_ptMouse))
		{
			Save();
		}
		
		else if (PtInRect(&rcLoad, g_ptMouse))
		{
			Load();
		}

		// ����Ÿ��
		if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
		{
			for (int i = 0; i < SAMPLE_TILE_X * SAMPLE_TILE_Y; i++)
			{
				if (PtInRect(&sampleTileInfo[i].rcTile, g_ptMouse))
				{
					selectTileInfo.frameX = sampleTileInfo[i].frameX;
					selectTileInfo.frameY = sampleTileInfo[i].frameY;
					selectTileInfos[0].frameX = sampleTileInfo[i].frameX;
					selectTileInfos[0].frameY = sampleTileInfo[i].frameY;
					isDownSampleArea = true;
					break;
				}
			}
		}
		else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
		{
			for (int i = 0; i < OBJECT_TILE_X * OBJECT_TILE_Y; i++)
			{
				if (PtInRect(&objectTileInfo[i].rcTile, g_ptMouse))
				{
					selectTileInfo.frameX = objectTileInfo[i].frameX;
					selectTileInfo.frameY = objectTileInfo[i].frameY;
					selectTileInfos[0].frameX = objectTileInfo[i].frameX;
					selectTileInfos[0].frameY = objectTileInfo[i].frameY;
					isDownSampleArea = true;
					break;
				}
			}
		}
		
	}
	else if ( KeyManager::GetSingleton()->IsOnceKeyUp(VK_LBUTTON) )
	{
		if (isDownSampleArea)
		{
			if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
			{
				for (int i = 0; i < SAMPLE_TILE_X * SAMPLE_TILE_Y; i++)
				{
					if (PtInRect(&sampleTileInfo[i].rcTile, g_ptMouse))
					{
						selectTileInfos[1].frameX = sampleTileInfo[i].frameX;
						selectTileInfos[1].frameY = sampleTileInfo[i].frameY;

						// �巡�� ������ ���� ����
						minX = min(selectTileInfos[0].frameX, selectTileInfos[1].frameX);
						minY = min(selectTileInfos[0].frameY, selectTileInfos[1].frameY);
						maxX = max(selectTileInfos[0].frameX, selectTileInfos[1].frameX);
						maxY = max(selectTileInfos[0].frameY, selectTileInfos[1].frameY);

						dragSizeX = maxX - minX;
						dragSizeY = maxY - minY;

						isDownSampleArea = false;
						break;
					}
				}
			}
			else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
			{
				for (int i = 0; i < OBJECT_TILE_X * OBJECT_TILE_Y; i++)
				{
					if (PtInRect(&objectTileInfo[i].rcTile, g_ptMouse))
					{
						selectTileInfos[1].frameX = objectTileInfo[i].frameX;
						selectTileInfos[1].frameY = objectTileInfo[i].frameY;

						// �巡�� ������ ���� ����
						minX = min(selectTileInfos[0].frameX, selectTileInfos[1].frameX);
						minY = min(selectTileInfos[0].frameY, selectTileInfos[1].frameY);
						maxX = max(selectTileInfos[0].frameX, selectTileInfos[1].frameX);
						maxY = max(selectTileInfos[0].frameY, selectTileInfos[1].frameY);

						dragSizeX = maxX - minX;
						dragSizeY = maxY - minY;

						isDownSampleArea = false;
						break;
					}
				}
			}
		}

		for (int i = 0; i < TILE_X * TILE_Y; i++)
		{
			if (PtInRect(&tileInfo[i].rcTile, g_ptMouse))
			{
				for (int y = 0; y < dragSizeY + 1; y++)
				{
					for (int x = 0; x < dragSizeX + 1; x++)
					{
						if ( (i % TILE_X) + x >= TILE_X ) continue;
						if ( (i / TILE_X) + y >= TILE_Y ) continue;
						tileInfo[i + y * TILE_X + x].frameX = minX + x;
						tileInfo[i + y * TILE_X + x].frameY = minY + y;

						if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
						{
							tileInfo[i + y * TILE_X + x].tileType = SAMPLE_TILE_TYPE::SAMPLE;
						}
						else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
						{
							tileInfo[i + y * TILE_X + x].tileType = SAMPLE_TILE_TYPE::OBJECT;
						}
					}
				}

				break;
			}
		}
	}
	else if (KeyManager::GetSingleton()->IsStayKeyDown(VK_LBUTTON))
	{
		// ����Ÿ��
		for (int i = 0; i < TILE_X * TILE_Y; i++)
		{
			if (PtInRect(&tileInfo[i].rcTile, g_ptMouse))
			{
				tileInfo[i].frameX = selectTileInfo.frameX;
				tileInfo[i].frameY = selectTileInfo.frameY;
				break;
			}
		}
	}
}

void TilemapToolScene::Render(HDC hdc)
{
	PatBlt(hdc, 0, 0, WINSIZE_TILE_MAP_X, WINSIZE_TILE_MAP_Y, WHITENESS);

	// ������ Ÿ�ϸ� ����
	if(sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
		sampleTileImage->Render(hdc, WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth(), 0);
	else if(sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
		objectTileImage->Render(hdc, WINSIZE_TILE_MAP_X - objectTileImage->GetWidth() + objectTileImage->GetWidth() / 2, objectTileImage->GetHeight() / 2 );

	//// ������ Ÿ��
	//if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
	//	sampleTileImage->FrameRender(hdc, WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth(),
	//		sampleTileImage->GetHeight() + 50, selectTileInfo.frameX, selectTileInfo.frameY);
	//else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
	//	objectTileImage->FrameRender(hdc, WINSIZE_TILE_MAP_X - objectTileImage->GetWidth(),
	//		objectTileImage->GetHeight() + 50, selectTileInfo.frameX, selectTileInfo.frameY);


	// �巡�� �� ���ø� �����ش�.
	for (int y = 0; y < dragSizeY + 1; y++)
	{
		for (int x = 0; x < dragSizeX + 1; x++)
		{
			if(sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
				sampleTileImage->FrameRender(hdc, WINSIZE_TILE_MAP_X - sampleTileImage->GetWidth() + (x * TILE_SIZE),
					sampleTileImage->GetHeight() + 50 + (y * TILE_SIZE), minX + x, minY + y);
			else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
				objectTileImage->FrameRender(hdc, WINSIZE_TILE_MAP_X - objectTileImage->GetWidth() + (x * TILE_SIZE),
					objectTileImage->GetHeight() + 50 + (y * TILE_SIZE), minX + x, minY + y);
		}
	}

	// ���� ���� Ÿ��
	for (int i = 0; i < TILE_X * TILE_Y; i++)
	{
		if (tileInfo[i].tileType == SAMPLE_TILE_TYPE::SAMPLE)
		{
			sampleTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
		}
	
		else if (tileInfo[i].tileType == SAMPLE_TILE_TYPE::OBJECT)
		{
			sampleTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
			objectTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
		}

		//if (sampleTileType == SAMPLE_TILE_TYPE::SAMPLE)
		//	sampleTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
		//else if (sampleTileType == SAMPLE_TILE_TYPE::OBJECT)
		//{
		//	//sampleTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
		//	objectTileImage->FrameRender(hdc, tileInfo[i].rcTile.left + (TILE_SIZE / 2), tileInfo[i].rcTile.top + (TILE_SIZE / 2), tileInfo[i].frameX, tileInfo[i].frameY);
		//}
	}

	// Ÿ�� & ���̺� & �ε� �̹���
	if (typeImage)
	{
		typeImage->Render(hdc, rcType.left + typeImage->GetWidth() / 2, rcType.top + typeImage->GetHeight() / 2);
	}

	if (saveImage)
	{
		//Rectangle(hdc, rcSave.left, rcSave.top, rcSave.right, rcSave.bottom);
		saveImage->Render(hdc, rcSave.left + saveImage->GetWidth() / 2, rcSave.top + saveImage->GetHeight() / 2);
	}
	
	if (loadImage)
	{
		//Rectangle(hdc, rcLoad.left, rcLoad.top, rcLoad.right, rcLoad.bottom);
		loadImage->Render(hdc, rcLoad.left + loadImage->GetWidth() / 2, rcSave.top + loadImage->GetHeight() / 2);
	}
	

	//TextOut(hdc, rcSave.left + 40, rcSave.top + 30, "���̺�", strlen("���̺�"));

	//Rectangle(hdc, rcLoad.left, rcLoad.top, rcLoad.right, rcLoad.bottom);
	//TextOut(hdc, rcLoad.left + 40, rcLoad.top + 30, "�ε�", strlen("�ε�"));
}

void TilemapToolScene::Save()
{
	//IFileSaveDialog

	/*OPENFILENAMEA ofn;
	char szFile[128];

	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = g_hWnd;
	ofn.hInstance = GetModuleHandle(NULL);
	ofn.lpstrFile = szFile;
	ofn.nFilterIndex = 0;
	ofn.nMaxFile = 256;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

	GetSaveFileName(&ofn);

	OPENFILENAME lpstrFile;

	GetSaveFileNameA(&lpstrFile);*/

	

	//���̺� �Ǵ� ����� �ؽ�Ʈ ���Ϸ� ���̺� //CREATE_ALWAYS : ������ ���� ������ش�.
	HANDLE hFile = CreateFile("Save/saveMapData.map", GENERIC_WRITE, 0, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	DWORD writtenByte;
	//IFileSaveDialog 
	//Save Dialog
	OPENFILENAME saveFileDialog;
	char szSaveFileName[MAX_PATH];
	ZeroMemory(&saveFileDialog, sizeof(saveFileDialog));
	saveFileDialog.lStructSize = sizeof(saveFileDialog);
	saveFileDialog.hwndOwner = g_hWnd;
	saveFileDialog.lpstrFilter = "Demonic Text (*.Dtxt)\0*.Dtxt\0Text Files (*.txt)\0*txt\0All Files (*.*)\0*.*\0";
	saveFileDialog.lpstrFile = szSaveFileName;
	saveFileDialog.nMaxFile = MAX_PATH;
	saveFileDialog.Flags = OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT;
	saveFileDialog.lpstrDefExt = "Dtxt";
	if (GetSaveFileName(&saveFileDialog)) {

	}

	// 2��° : ���Ͽ��ٰ� ������ �������� �ּ�, 3��° : �����ּҺ��� �󸶸�ŭ ������ ���ΰ�. //tileInfo : ������ ������ �ּ�
	WriteFile(hFile, tileInfo, sizeof(TILE_INFO) * TILE_X * TILE_Y, &writtenByte, NULL);

	CloseHandle(hFile); //�� ���� �ݾ��ֱ�.
}

void TilemapToolScene::Load()
{
	DWORD readByte;
	HANDLE hFile;

	hFile = CreateFile("Save/saveMapData.map", GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL); //������ ���� ������ �ȿ���
	ReadFile(hFile, tileInfo, sizeof(TILE_INFO) * TILE_X * TILE_Y, &readByte, NULL);
	CloseHandle(hFile);
}

TilemapToolScene::TilemapToolScene()
{
}

TilemapToolScene::~TilemapToolScene()
{
}
